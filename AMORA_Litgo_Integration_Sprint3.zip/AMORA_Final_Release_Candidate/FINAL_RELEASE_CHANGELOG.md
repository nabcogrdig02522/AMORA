# Final Release Candidate Changelog

## Added
- Sprint 10 admin member management, status controls and aggregate analytics.
- Admin-only SQL RPCs for member status, report review and verification review, with audit log records.
- Aggregated reporting views for registrations, payments and subscriptions.
- Deployment runbook, QA plan, founder launch checklist and release risk register.

## Existing features retained
- Member profile and preferences, compatibility/discovery, likes/matches, messaging, subscriptions, Ghana Paystack payment scaffold, regional market catalogue/cross-border opt-in, reports, blocks, selfie review and deletion request.

## Not claimed
- No live Supabase deployment, payment settlement, SMS delivery, automated ID/liveness verification, production build, app-store approval, legal clearance or production penetration test has been performed.


## 1 December 2026 – Litgo reference feature integration
- Added a Social destination to the AMORA bottom navigation.
- Added a text-first Moments feed with authenticated publishing, blocked-member visibility filtering and Supabase Realtime updates.
- Added a once-per-UTC-day check-in reward flow, enforced server-side with a unique daily key and an atomic wallet update.
- Added transparent roadmap entries for virtual gifts, voice matching, audio/video calling, live rooms and message translation. These are not enabled pending their provider, safety and backend integrations.

## Litgo-reference integration update (2 December 2026)
- Added Moments image and short-video attachments, likes and comments.
- Added private Supabase media storage with signed access URLs and ownership policies.
- Added video playback to the Moments feed.
- Added migration `20261202_moments_media_interactions.sql`.
- Added integration and QA notes in `docs/LITGO_FEATURE_INTEGRATION_SPRINT.md`.
- Added profile photo upload and discovery-card photo rendering using the existing `profiles.photo_url` field.
