# AMORA – Litgo-inspired integration sprint

## Delivered in this source package
- Moments support text and image/video attachments.
- Image picker and video picker; selected video duration is limited to 60 seconds.
- In-app video playback and image rendering from time-limited signed URLs.
- Moment likes and comments.
- Daily check-in/reward foundation retained.
- Private `moment-media` bucket and storage RLS policies.
- Active-account and block-aware row-level access for Moment interactions.

## Database migration order
Apply all prior AMORA migrations first, then:
1. `20261201_social_engagement.sql`
2. `20261202_moments_media_interactions.sql`

## Supabase setup
The migration creates a private `moment-media` bucket (50 MB maximum per object) with image/video MIME allow-list. The Flutter client uses the authenticated user's UUID as the first path segment. Realtime must be enabled for `social_moments` if the feed is to stream updates.

## QA still required
- Flutter dependency resolution, analyzer, widget tests and Android build.
- Supabase migration execution on a staging project.
- Validate upload, signed URL retrieval, video playback, like/comment RLS and block behavior using two test accounts.
- Add moderation/report controls for Moments media before public launch.

## Known limitations
The client currently displays generic member labels in the feed rather than resolving profile names. Video playback is implemented, but automated transcoding, thumbnail generation, content scanning, and adaptive streaming are not. This sprint does not add virtual gifts, voice/video calls, live rooms or message translation.

## Additional profile media slice
- Added profile photo selection and upload to the `profile-media` bucket.
- Profile photo URL is saved to `profiles.photo_url` and displayed on discovery cards.
- Profile media uploads are restricted to the signed-in member's UUID folder; profile images are publicly readable to support discovery cards. Do not upload sensitive/private images to this bucket.
