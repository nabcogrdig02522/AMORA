# AMORA Litgo Reference Integration – Sprint 3

## Delivered
- Virtual gift catalogue (rose, coffee, chocolate, teddy bear, heart, crown).
- Gift sending from an authenticated member to another active member.
- Atomic server-side points deduction with wallet-row locking to prevent concurrent overspending.
- Weekly leaderboard based on gifts received.
- Block-aware recipient selection and leaderboard filtering.
- Gift economy is deliberately non-cash: points cannot be withdrawn, transferred, or redeemed for money.

## Database
Apply `supabase/migrations/20261203_virtual_gifts_leaderboard.sql` after
`20261202_moments_media_interactions.sql`.

The migration creates `amora_gift_catalog`, `amora_gift_transactions`,
`amora_send_gift`, `amora_my_gift_balance`, and `amora_gift_leaderboard`.

## App navigation
A gift icon in the AMORA app bar opens **Gifts & leaderboard**. The screen
shows the current points balance, catalogue, recipient picker and weekly rankings.

## Important limitations
- The only currently defined earning path is the existing daily check-in (5 points/day).
- This sprint does not connect gifts to cash, Paystack, subscriptions, or cash-out.
- The leaderboard displays only members with gifts received in the current UTC week.
- Database migration and Flutter compilation must be run in the target Supabase/Flutter environment before release.
- The APK has not been built or verified in this sprint.

## QA checklist
1. Apply migrations in order through `20261203_virtual_gifts_leaderboard.sql`.
2. Confirm an authenticated user can load gift catalogue and balance.
3. Confirm self-gifting is rejected.
4. Confirm blocked-member gifting is rejected.
5. Confirm insufficient balance is rejected without a transaction.
6. Confirm concurrent sends cannot make points balance negative.
7. Confirm successful send deducts exactly the catalogue price.
8. Confirm leaderboard counts only gifts in the current week.
9. Confirm users cannot insert/update/delete gift transactions directly.
