import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:image_picker/image_picker.dart';
import '../services/social_media_service.dart';
import 'package:video_player/video_player.dart';

class SocialHubScreen extends StatefulWidget {
  const SocialHubScreen({super.key});
  @override
  State<SocialHubScreen> createState() => _SocialHubScreenState();
}

class _SocialHubScreenState extends State<SocialHubScreen> {
  final _client = Supabase.instance.client;
  final _postController = TextEditingController();
  late final SocialMediaService _media = SocialMediaService(_client);
  XFile? _selectedMedia;
  bool _selectedVideo = false;
  bool _posting = false;
  bool _checkingIn = false;
  String? _message;

  @override
  void dispose() {
    _postController.dispose();
    super.dispose();
  }

  Future<void> _publishMoment() async {
    final body = _postController.text.trim();
    if ((body.isEmpty && _selectedMedia == null) || body.length > 1000 || _posting) return;
    setState(() { _posting = true; _message = null; });
    String? mediaPath;
    try {
      if (_selectedMedia != null) {
        mediaPath = await _media.uploadMomentMedia(_selectedMedia!, video: _selectedVideo);
      }
      await _client.from('social_moments').insert({
        'author_id': _client.auth.currentUser!.id,
        'body': body,
        'media_path': mediaPath,
        'media_type': mediaPath == null ? null : (_selectedVideo ? 'video' : 'image'),
      });
      _selectedMedia = null;
      _selectedVideo = false;
      _postController.clear();
      if (mounted) {
        setState(() => _message = 'Your Moment has been shared.');
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Moment published.')),
        );
      }
    } on PostgrestException catch (e) {
      if (mediaPath != null) { try { await _media.deleteMomentMedia(mediaPath); } catch (_) {} }
      if (mounted) setState(() => _message = 'Could not publish: ${e.message}');
    } catch (_) {
      if (mediaPath != null) { try { await _media.deleteMomentMedia(mediaPath); } catch (_) {} }
      if (mounted) setState(() => _message = 'Could not publish your Moment. Please try again.');
    } finally {
      if (mounted) setState(() => _posting = false);
    }
  }

  Future<void> _checkIn() async {
    if (_checkingIn) return;
    setState(() { _checkingIn = true; _message = null; });
    try {
      final result = await _client.rpc('amora_daily_check_in');
      final points = (result as num).toInt();
      if (mounted) setState(() {
        _message = points > 0
            ? 'You earned $points AMORA points today.'
            : 'You have already checked in today. Come back tomorrow.';
      });
    } on PostgrestException catch (e) {
      if (mounted) setState(() => _message = 'Check-in unavailable: ${e.message}. Apply the social engagement migration.');
    } catch (_) {
      if (mounted) setState(() => _message = 'Check-in is temporarily unavailable.');
    } finally {
      if (mounted) setState(() => _checkingIn = false);
    }
  }

  Future<void> _chooseMedia({required bool video}) async {
    final picked = video ? await _media.pickVideo() : await _media.pickImage();
    if (picked != null && mounted) setState(() { _selectedMedia = picked; _selectedVideo = video; });
  }

  Future<void> _compose() async {
    _postController.clear();
    _selectedMedia = null;
    _selectedVideo = false;
    _message = null;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => Padding(
        padding: EdgeInsets.fromLTRB(18, 8, 18, MediaQuery.of(sheetContext).viewInsets.bottom + 22),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('Share a Moment', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          TextField(
            controller: _postController,
            autofocus: true,
            maxLength: 1000,
            maxLines: 5,
            decoration: const InputDecoration(
              hintText: 'What would you like the AMORA community to know?',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 8),
          Wrap(spacing: 8, children: [
            OutlinedButton.icon(onPressed: () => _chooseMedia(video: false), icon: const Icon(Icons.photo_outlined), label: const Text('Add photo')),
            OutlinedButton.icon(onPressed: () => _chooseMedia(video: true), icon: const Icon(Icons.videocam_outlined), label: const Text('Add video (60 sec)')),
          ]),
          if (_selectedMedia != null) Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text('Selected: ${_selectedMedia!.name}')),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: _posting ? null : () async {
              await _publishMoment();
              if (mounted && _message == 'Your Moment has been shared.') {
                Navigator.of(sheetContext).pop();
              }
            },
            icon: const Icon(Icons.send),
            label: Text(_posting ? 'Publishing…' : 'Publish Moment'),
          ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('AMORA Social'),
          bottom: const TabBar(tabs: [
            Tab(icon: Icon(Icons.dynamic_feed_outlined), text: 'Moments'),
            Tab(icon: Icon(Icons.stars_outlined), text: 'Rewards'),
          ]),
          actions: [
            IconButton(tooltip: 'Create a Moment', onPressed: _compose, icon: const Icon(Icons.add_circle_outline)),
          ],
        ),
        body: TabBarView(children: [
          _momentsFeed(),
          _rewards(),
        ]),
      ),
    );
  }

  Widget _momentsFeed() {
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
        child: Card(
          child: ListTile(
            leading: const CircleAvatar(child: Icon(Icons.edit_note)),
            title: const Text('Share something real', style: TextStyle(fontWeight: FontWeight.bold)),
            subtitle: const Text('Post a thought or a small moment from your day.'),
            trailing: IconButton(onPressed: _compose, icon: const Icon(Icons.add, color: Color(0xFF7B2348))),
          ),
        ),
      ),
      Expanded(
        child: StreamBuilder<List<Map<String, dynamic>>>(
          stream: _client.from('social_moments').stream(primaryKey: ['id']).order('created_at', ascending: false).limit(50),
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return const Center(child: Padding(
                padding: EdgeInsets.all(24),
                child: Text('Moments are not connected yet. Apply the AMORA social engagement migration and enable Supabase Realtime for social_moments.', textAlign: TextAlign.center),
              ));
            }
            if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
            final rows = snapshot.data!;
            if (rows.isEmpty) return const Center(child: Text('No Moments yet. Be the first to share one.'));
            return ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              itemCount: rows.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, index) {
                final row = rows[index];
                final mine = row['author_id'] == _client.auth.currentUser?.id;
                final created = DateTime.tryParse('${row['created_at'] ?? ''}')?.toLocal();
                final when = created == null ? '' : '${created.day}/${created.month}/${created.year}';
                return Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        CircleAvatar(
                          backgroundColor: const Color(0xFFF1D7E2),
                          child: Icon(mine ? Icons.person : Icons.favorite_border, color: const Color(0xFF7B2348)),
                        ),
                        const SizedBox(width: 10),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(mine ? 'You' : 'AMORA member', style: const TextStyle(fontWeight: FontWeight.bold)),
                          Text(when, style: const TextStyle(fontSize: 12, color: Colors.black54)),
                        ])),
                        if (mine) const Icon(Icons.verified_user_outlined, size: 18, color: Colors.black45),
                      ]),
                      const SizedBox(height: 12),
                      if ((row['body'] ?? '').toString().isNotEmpty) Text('${row['body']}', style: const TextStyle(fontSize: 15, height: 1.4)),
                      if (row['media_path'] != null) _momentMedia('${row['media_path']}', '${row['media_type'] ?? 'image'}'),
                      const SizedBox(height: 8),
                      _momentActions('${row['id']}'),
                    ]),
                  ),
                );
              },
            );
          },
        ),
      ),
    ]);
  }

  Widget _momentMedia(String path, String type) {
    return FutureBuilder<String>(
      future: _media.signedMomentUrl(path),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const Padding(
          padding: EdgeInsets.symmetric(vertical: 16),
          child: Center(child: CircularProgressIndicator()),
        );
        if (type == 'video') return _MomentVideo(url: snapshot.data!);
        return Padding(
          padding: const EdgeInsets.only(top: 12),
          child: ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.network(
            snapshot.data!, height: 230, width: double.infinity, fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => const SizedBox(height: 100, child: Center(child: Text('Media unavailable'))),
          )),
        );
      },
    );
  }

  Widget _momentActions(String momentId) {
    return Row(children: [
      TextButton.icon(
        onPressed: () async {
          try { await _media.toggleLike(momentId); }
          catch (_) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not update like.'))); }
        },
        icon: const Icon(Icons.favorite_border), label: const Text('Like'),
      ),
      TextButton.icon(
        onPressed: () => _openComments(momentId),
        icon: const Icon(Icons.mode_comment_outlined), label: const Text('Comment'),
      ),
    ]);
  }

  Future<void> _openComments(String momentId) async {
    final controller = TextEditingController();
    await showModalBottomSheet<void>(
      context: context, isScrollControlled: true, showDragHandle: true,
      builder: (sheetContext) => Padding(
        padding: EdgeInsets.fromLTRB(16, 8, 16, MediaQuery.of(sheetContext).viewInsets.bottom + 16),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('Comments', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          SizedBox(height: 260, child: FutureBuilder<List<Map<String, dynamic>>>(
            future: _client.from('moment_comments').select('body, created_at').eq('moment_id', momentId).order('created_at'),
            builder: (context, snapshot) {
              if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
              final comments = snapshot.data!;
              if (comments.isEmpty) return const Center(child: Text('Be the first to comment.'));
              return ListView(children: comments.map((c) => ListTile(
                leading: const CircleAvatar(child: Icon(Icons.person_outline)),
                title: Text('${c['body']}'),
              )).toList());
            },
          )),
          TextField(controller: controller, maxLength: 500, decoration: const InputDecoration(hintText: 'Write a respectful comment', border: OutlineInputBorder())),
          const SizedBox(height: 8),
          FilledButton(onPressed: () async {
            try { await _media.addComment(momentId, controller.text); if (sheetContext.mounted) Navigator.pop(sheetContext); }
            catch (_) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not post comment.'))); }
          }, child: const Text('Post comment')),
        ]),
      ),
    );
    controller.dispose();
  }

  Widget _rewards() {
    return ListView(padding: const EdgeInsets.all(18), children: [
      Card(
        color: const Color(0xFFF8EAF0),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Icon(Icons.calendar_month, color: Color(0xFF7B2348), size: 34),
            const SizedBox(height: 10),
            const Text('Daily check-in', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text('Visit AMORA each day to earn engagement points. One reward is available per calendar day.'),
            const SizedBox(height: 14),
            FilledButton.icon(
              onPressed: _checkingIn ? null : _checkIn,
              icon: _checkingIn
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.check_circle_outline),
              label: Text(_checkingIn ? 'Checking in…' : 'Check in today'),
            ),
            if (_message != null) Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Text(_message!, style: const TextStyle(fontWeight: FontWeight.w600)),
            ),
          ]),
        ),
      ),
      const SizedBox(height: 16),
      const Text('More ways to connect', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      _comingFeature(Icons.card_giftcard, 'Virtual gifts', 'Send appreciation gifts after a mutual connection.', 'Planned'),
      _comingFeature(Icons.mic_none, 'Voice matching', 'Discover a connection through short voice introductions.', 'Planned'),
      _comingFeature(Icons.video_call_outlined, 'Audio and video calls', 'Move a mutual match into a safer in-app conversation.', 'Integration required'),
      _comingFeature(Icons.live_tv_outlined, 'Live rooms', 'Join moderated community conversations and events.', 'Planned'),
      _comingFeature(Icons.translate, 'Message translation', 'Help members communicate across languages.', 'Planned'),
      const SizedBox(height: 10),
      const Text(
        'Points are engagement rewards only. They are not cash, cannot be withdrawn, and do not buy gifts or subscriptions in this release.',
        style: TextStyle(fontSize: 12, color: Colors.black54),
      ),
    ]);
  }

  Widget _comingFeature(IconData icon, String title, String subtitle, String status) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(backgroundColor: const Color(0xFFF1D7E2), child: Icon(icon, color: const Color(0xFF7B2348))),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle),
        trailing: Text(status, style: const TextStyle(fontSize: 11, color: Colors.black54)),
      ),
    );
  }
}


class _MomentVideo extends StatefulWidget {
  const _MomentVideo({required this.url});
  final String url;
  @override
  State<_MomentVideo> createState() => _MomentVideoState();
}

class _MomentVideoState extends State<_MomentVideo> {
  late final VideoPlayerController _controller;
  bool _ready = false;
  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
      ..initialize().then((_) { if (mounted) setState(() => _ready = true); });
  }
  @override
  void dispose() { _controller.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    if (!_ready) return const SizedBox(height: 190, child: Center(child: CircularProgressIndicator()));
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: AspectRatio(
          aspectRatio: _controller.value.aspectRatio,
          child: Stack(alignment: Alignment.center, children: [
            VideoPlayer(_controller),
            IconButton.filledTonal(
              onPressed: () => setState(() => _controller.value.isPlaying ? _controller.pause() : _controller.play()),
              iconSize: 38,
              icon: Icon(_controller.value.isPlaying ? Icons.pause : Icons.play_arrow),
            ),
            Positioned(left: 8, right: 8, bottom: 4, child: VideoProgressIndicator(_controller, allowScrubbing: true)),
          ]),
        ),
      ),
    );
  }
}
