import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/gift_service.dart';

class GiftEconomyScreen extends StatefulWidget {
  const GiftEconomyScreen({super.key});
  @override
  State<GiftEconomyScreen> createState() => _GiftEconomyScreenState();
}

class _GiftEconomyScreenState extends State<GiftEconomyScreen> {
  late final AmoraGiftService _service = AmoraGiftService(Supabase.instance.client);
  late Future<int> _balance = _service.balance();
  late Future<List<Map<String,dynamic>>> _catalogue = _service.catalogue();
  late Future<List<Map<String,dynamic>>> _leaders = _service.leaderboard();
  bool _sending = false;
  String? _notice;

  Future<void> _refresh() async {
    setState(() {
      _balance = _service.balance();
      _catalogue = _service.catalogue();
      _leaders = _service.leaderboard();
    });
  }

  Future<void> _chooseRecipient(Map<String,dynamic> gift) async {
    final recipients = await _service.recipients();
    if (!mounted) return;
    if (recipients.isEmpty) {
      setState(() => _notice = 'There are no available members to receive a gift yet.');
      return;
    }
    final selected = await showModalBottomSheet<Map<String,dynamic>>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(child: SizedBox(
        height: 460,
        child: Column(children: [
          Padding(padding: const EdgeInsets.all(16), child: Text('Send ${gift['emoji']} ${gift['title']}', style: const TextStyle(fontSize: 19,fontWeight: FontWeight.bold))),
          Expanded(child: ListView.builder(
            itemCount: recipients.length,
            itemBuilder: (context,index) {
              final member=recipients[index];
              return ListTile(
                leading: CircleAvatar(
                  backgroundImage: (member['photo_url'] is String && (member['photo_url'] as String).startsWith('http'))
                    ? NetworkImage(member['photo_url']) : null,
                  child: member['photo_url']==null ? const Icon(Icons.person_outline) : null,
                ),
                title: Text('${member['display_name']}'),
                subtitle: Text('${member['city'] ?? 'AMORA member'}'),
                onTap: () => Navigator.pop(ctx,member),
              );
            },
          )),
        ]),
      )),
    );
    if (selected == null || !mounted) return;
    setState(() { _sending=true; _notice=null; });
    try {
      final remaining=await _service.send(
        recipientId: '${selected['id']}',
        giftId: '${gift['id']}',
      );
      if (mounted) setState(() {
        _notice='${gift['emoji']} Gift sent to ${selected['display_name']}. Your balance is $remaining points.';
        _balance=Future.value(remaining);
        _leaders=_service.leaderboard();
      });
    } on PostgrestException catch(e) {
      if (mounted) setState(()=>_notice=e.message);
    } catch (_) {
      if (mounted) setState(()=>_notice='Could not send the gift. Please try again.');
    } finally {
      if (mounted) setState(()=>_sending=false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Gifts & leaderboard')),
    body: RefreshIndicator(
      onRefresh: _refresh,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        Card(
          color: const Color(0xFFF8EAF0),
          child: Padding(padding: const EdgeInsets.all(18), child: Row(children: [
            const Icon(Icons.account_balance_wallet_outlined,size:34,color:Color(0xFF7B2348)),
            const SizedBox(width:12),
            Expanded(child: Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
              const Text('Your AMORA points',style:TextStyle(fontWeight:FontWeight.bold)),
              FutureBuilder<int>(future:_balance,builder:(context,s)=>Text(
                s.hasData?'${s.data} points':s.hasError?'Balance unavailable':'Loading…',
                style:const TextStyle(fontSize:23,fontWeight:FontWeight.w800))),
            ])),
            const Text('Non-cash rewards',style:TextStyle(fontSize:11,color:Colors.black54)),
          ])),
        ),
        if (_notice != null) Padding(padding:const EdgeInsets.symmetric(vertical:10),child:Text(_notice!,style:const TextStyle(color:Color(0xFF7B2348)))),
        const SizedBox(height:12),
        const Text('Send a little appreciation',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
        const Padding(padding:EdgeInsets.only(top:4,bottom:10),child:Text('Use points earned through AMORA engagement to send virtual gifts. Points have no cash value.')),
        FutureBuilder<List<Map<String,dynamic>>>(future:_catalogue,builder:(context,snapshot){
          if(snapshot.hasError)return const Text('Gift catalogue unavailable. Apply the virtual gifts migration.');
          if(!snapshot.hasData)return const Center(child:CircularProgressIndicator());
          return GridView.builder(
            shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),
            itemCount:snapshot.data!.length,
            gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,childAspectRatio:1.55,crossAxisSpacing:10,mainAxisSpacing:10),
            itemBuilder:(context,index){
              final gift=snapshot.data![index];
              return Card(child:InkWell(
                borderRadius:BorderRadius.circular(12),
                onTap:_sending?null:()=>_chooseRecipient(gift),
                child:Padding(padding:const EdgeInsets.all(12),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
                  Text('${gift['emoji']}',style:const TextStyle(fontSize:30)),
                  Text('${gift['title']}',style:const TextStyle(fontWeight:FontWeight.bold)),
                  Text('${gift['points_cost']} points',style:const TextStyle(color:Color(0xFF7B2348))),
                  const SizedBox(height:4),
                  const Text('Tap to send',style:TextStyle(fontSize:11,color:Colors.black54)),
                ])),
              ));
            },
          );
        }),
        const SizedBox(height:22),
        const Text('This week’s appreciation leaderboard',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
        const Padding(padding:EdgeInsets.only(top:4,bottom:8),child:Text('Ranked by virtual gifts received since Monday. Members who have blocked you, or whom you have blocked, are not shown.')),
        FutureBuilder<List<Map<String,dynamic>>>(future:_leaders,builder:(context,snapshot){
          if(snapshot.hasError)return const Text('Leaderboard unavailable. Apply the virtual gifts migration.');
          if(!snapshot.hasData)return const Center(child:CircularProgressIndicator());
          final rows=snapshot.data!;
          if(rows.isEmpty)return const Card(child:ListTile(leading:Icon(Icons.emoji_events_outlined),title:Text('No gifts received this week yet'),subtitle:Text('Send a thoughtful gift to get things started.')));
          return Card(child:Column(children:List.generate(rows.length,(i){
            final row=rows[i];
            final url=row['photo_url']?.toString()??'';
            return ListTile(
              leading:CircleAvatar(
                backgroundImage:url.startsWith('http')?NetworkImage(url):null,
                child:url.startsWith('http')?null:Text('${i+1}'),
              ),
              title:Text('${row['display_name']}',style:const TextStyle(fontWeight:FontWeight.w600)),
              subtitle:Text('${row['gifts_received']} gifts received'),
              trailing:Text('${row['points_received']} pts',style:const TextStyle(fontWeight:FontWeight.bold,color:Color(0xFF7B2348))),
            );
          }))),
        }),
      ]),
    ),
  );
}
