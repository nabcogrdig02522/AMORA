import 'package:supabase_flutter/supabase_flutter.dart';

class AmoraGiftService {
  AmoraGiftService(this.client);
  final SupabaseClient client;

  Future<int> balance() async {
    final value = await client.rpc('amora_my_gift_balance');
    return (value as num?)?.toInt() ?? 0;
  }

  Future<List<Map<String, dynamic>>> catalogue() async {
    final rows = await client.from('amora_gift_catalog')
        .select('id,title,emoji,points_cost')
        .eq('active', true).order('sort_order');
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<List<Map<String, dynamic>>> recipients() async {
    final uid = client.auth.currentUser?.id;
    if (uid == null) return [];
    final rows = await client.from('profiles')
        .select('id,display_name,city,photo_url')
        .eq('is_active', true).neq('id', uid)
        .order('display_name').limit(50);
    return List<Map<String, dynamic>>.from(rows);
  }

  Future<List<Map<String, dynamic>>> leaderboard() async {
    final rows = await client.rpc('amora_gift_leaderboard', params: {'p_limit': 20});
    return List<Map<String, dynamic>>.from(rows as List);
  }

  Future<int> send({required String recipientId, required String giftId}) async {
    final result = await client.rpc('amora_send_gift', params: {
      'p_recipient_id': recipientId,
      'p_gift_id': giftId,
    });
    final rows = List<Map<String, dynamic>>.from(result as List);
    return (rows.first['points_remaining'] as num).toInt();
  }
}
