import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SocialMediaService {
  SocialMediaService(this.client);
  final SupabaseClient client;
  final ImagePicker _picker = ImagePicker();

  Future<XFile?> pickImage({ImageSource source = ImageSource.gallery}) =>
      _picker.pickImage(source: source, imageQuality: 82, maxWidth: 1920);

  Future<XFile?> pickVideo() => _picker.pickVideo(
        source: ImageSource.gallery,
        maxDuration: const Duration(seconds: 60),
      );

  Future<String> uploadMomentMedia(XFile file, {required bool video}) async {
    final uid = client.auth.currentUser?.id;
    if (uid == null) throw const AuthException('Please sign in again.');
    final extension = video ? 'mp4' : 'jpg';
    final path = '$uid/${DateTime.now().microsecondsSinceEpoch}.$extension';
    final bytes = await file.readAsBytes();
    if (bytes.length > 50 * 1024 * 1024) {
      throw Exception('Media must be smaller than 50 MB.');
    }
    await client.storage.from('moment-media').uploadBinary(
      path,
      bytes,
      fileOptions: FileOptions(
        contentType: video ? 'video/mp4' : 'image/jpeg',
        upsert: false,
      ),
    );
    return path;
  }

  Future<String> signedMomentUrl(String path) =>
      client.storage.from('moment-media').createSignedUrl(path, 3600);

  Future<void> deleteMomentMedia(String path) =>
      client.storage.from('moment-media').remove([path]);

  Future<void> toggleLike(String momentId) async {
    final uid = client.auth.currentUser!.id;
    final existing = await client.from('moment_likes').select('moment_id')
        .eq('moment_id', momentId).eq('user_id', uid).maybeSingle();
    if (existing == null) {
      await client.from('moment_likes').insert({'moment_id': momentId, 'user_id': uid});
    } else {
      await client.from('moment_likes').delete()
          .eq('moment_id', momentId).eq('user_id', uid);
    }
  }

  Future<void> addComment(String momentId, String body) async {
    final text = body.trim();
    if (text.isEmpty || text.length > 500) return;
    await client.from('moment_comments').insert({
      'moment_id': momentId,
      'author_id': client.auth.currentUser!.id,
      'body': text,
    });
  }
}
