# Litgo 1.2.8 reference review for AMORA

This review is based on the visible Flutter asset/resource inventory extracted from the supplied APK. It identifies product patterns and feature areas; it does not claim access to Litgo's private source code or backend.

## Reference feature areas observed
- Discovery/matching controls and profile details.
- Moments/social feed imagery and interactions.
- Voice matching, audio/video calling and live-room assets.
- Virtual gifts, gift ranking and VIP/subscription artwork.
- Daily check-in, tasks and rewards assets.
- Messaging utilities including media, read state, translation and message controls.

## AMORA implementation decisions
AMORA retains its own brand, interface, trust/safety requirements, and Ghana-first positioning. The following are the next implementation slice:
- Text, photo and short-video Moments (video capped at 60 seconds in the picker).
- Likes and comments.
- Private Supabase media storage with authenticated signed URLs.
- RLS checks for active accounts, ownership and blocks.

## Not yet implemented
Virtual gifts/leaderboards, voice matching, calling, live rooms, chat translation, profile media gallery, and independent age assurance remain separate workstreams. Do not market them as live features until their services, moderation and QA are completed.
