# Sprint 3 changelog

- Added virtual gift catalogue and points-based gift sending.
- Added atomic server-side wallet debit RPC and gift transaction ledger.
- Added weekly gift leaderboard with block-aware filtering.
- Added Gifts & leaderboard screen and app-bar entry point.
- No cash redemption or real-money transfer is supported.
