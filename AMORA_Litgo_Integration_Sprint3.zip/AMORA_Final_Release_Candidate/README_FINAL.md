# AMORA Final Release Candidate

This is the consolidated working package for the AMORA Ghana-first dating platform and planned West African expansion.

Start with `FINAL_RELEASE_PLAN.md`. Review `docs/DEPLOYMENT_RUNBOOK.md`, `docs/QA_TEST_PLAN.md`, `docs/LAUNCH_CHECKLIST.md` and `docs/RELEASE_RISK_REGISTER.md` before any live deployment.

**Status:** implementation candidate / staging handoff. Not production-live.

The Flutter project is at this package root. The founder console is in `backend_reference/AMORA_Sprint2/admin`. The ordered core and feature migrations are in `supabase/migrations`; apply them to a clean staging project first, and reconcile carefully before using an existing database.


## Android APK
The source bundle includes a GitHub Actions workflow to generate a QA APK on a hosted Flutter/Android runner. Follow `docs/ANDROID_APK_BUILD.md`. A production-signed APK/AAB requires the founder's Android signing keystore and secrets; no keystore or APK was available in this authoring environment.


## Social engagement update (1 December 2026)

The Social tab adds a text-first Moments feed and a server-authoritative daily check-in
that awards five non-cash engagement points once per UTC calendar day. Members can
publish, view and receive live updates for Moments after the migration is applied and
Supabase Realtime is enabled for `social_moments`.

The Social tab also presents the planned product areas identified during the Litgo
reference-app review: virtual gifts, voice matching, audio/video calls, live rooms and
message translation. These are clearly marked as planned or requiring integration;
they are not represented as operational features. In particular, real-time calling/live
rooms require a configured RTC provider, moderation workflows, consent controls and
production testing. Photo/video Moments and gifts require media storage, moderation,
wallet/ledger and payment controls before launch.

Apply `supabase/migrations/20261201_social_engagement.sql` after the existing
`20261130_release_candidate_admin_analytics.sql` migration.

## Social Moments media update
For photo/video Moments, apply `supabase/migrations/20261202_moments_media_interactions.sql` after `20261201_social_engagement.sql`. The app uses a private Supabase Storage bucket named `moment-media`; the migration creates it and configures authenticated upload/read/delete policies. Video selection is limited to 60 seconds and 50 MB per media object. Complete staging QA before production rollout.
