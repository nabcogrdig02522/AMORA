-- AMORA Moments: image/video attachments, likes and comments.
-- Apply after 20261201_social_engagement.sql.

alter table public.social_moments
  add column if not exists media_path text,
  add column if not exists media_type text;

-- Allow a media-only Moment while still rejecting completely empty posts.
alter table public.social_moments drop constraint if exists social_moments_body_check;
alter table public.social_moments drop constraint if exists social_moments_body_media_check;
alter table public.social_moments alter column body set default '';
alter table public.social_moments add constraint social_moments_body_media_check
  check (char_length(trim(body)) <= 1000 and
    (char_length(trim(body)) > 0 or media_path is not null));

alter table public.social_moments
  drop constraint if exists social_moments_media_type_check;
alter table public.social_moments
  add constraint social_moments_media_type_check
  check (media_type is null or media_type in ('image', 'video'));
alter table public.social_moments
  drop constraint if exists social_moments_media_pair_check;
alter table public.social_moments
  add constraint social_moments_media_pair_check
  check ((media_path is null and media_type is null) or
         (media_path is not null and media_type is not null));

create table if not exists public.moment_likes (
  moment_id uuid not null references public.social_moments(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (moment_id, user_id)
);
create index if not exists moment_likes_user_idx on public.moment_likes(user_id, created_at desc);
alter table public.moment_likes enable row level security;

drop policy if exists "active members read moment likes" on public.moment_likes;
create policy "active members read moment likes" on public.moment_likes
for select to authenticated using (
  exists (select 1 from public.profiles p where p.id = auth.uid()
    and p.is_active = true and coalesce(p.account_status, 'active') = 'active')
  and exists (select 1 from public.social_moments m where m.id = moment_id)
);
drop policy if exists "members like moments as themselves" on public.moment_likes;
create policy "members like moments as themselves" on public.moment_likes
for insert to authenticated with check (
  user_id = auth.uid()
  and exists (select 1 from public.profiles p where p.id = auth.uid()
    and p.is_active = true and coalesce(p.account_status, 'active') = 'active')
  and exists (select 1 from public.social_moments m where m.id = moment_id
    and not exists (select 1 from public.blocks b
      where (b.blocker_id = auth.uid() and b.blocked_id = m.author_id)
         or (b.blocker_id = m.author_id and b.blocked_id = auth.uid())))
);
drop policy if exists "members remove own moment likes" on public.moment_likes;
create policy "members remove own moment likes" on public.moment_likes
for delete to authenticated using (user_id = auth.uid());

create table if not exists public.moment_comments (
  id uuid primary key default gen_random_uuid(),
  moment_id uuid not null references public.social_moments(id) on delete cascade,
  author_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(trim(body)) between 1 and 500),
  created_at timestamptz not null default now()
);
create index if not exists moment_comments_moment_idx on public.moment_comments(moment_id, created_at);
alter table public.moment_comments enable row level security;

drop policy if exists "active members read comments on visible moments" on public.moment_comments;
create policy "active members read comments on visible moments" on public.moment_comments
for select to authenticated using (
  exists (select 1 from public.profiles p where p.id = auth.uid()
    and p.is_active = true and coalesce(p.account_status, 'active') = 'active')
  and exists (select 1 from public.social_moments m where m.id = moment_id)
);
drop policy if exists "members comment on visible moments" on public.moment_comments;
create policy "members comment on visible moments" on public.moment_comments
for insert to authenticated with check (
  author_id = auth.uid()
  and exists (select 1 from public.profiles p where p.id = auth.uid()
    and p.is_active = true and coalesce(p.account_status, 'active') = 'active')
  and exists (select 1 from public.social_moments m where m.id = moment_id
    and not exists (select 1 from public.blocks b
      where (b.blocker_id = auth.uid() and b.blocked_id = m.author_id)
         or (b.blocker_id = m.author_id and b.blocked_id = auth.uid())))
);
drop policy if exists "members edit own moment comments" on public.moment_comments;
create policy "members edit own moment comments" on public.moment_comments
for update to authenticated using (author_id = auth.uid())
with check (author_id = auth.uid() and char_length(trim(body)) between 1 and 500);
drop policy if exists "members delete own moment comments" on public.moment_comments;
create policy "members delete own moment comments" on public.moment_comments
for delete to authenticated using (author_id = auth.uid());

-- Private media bucket: object paths must begin with the authenticated user's UUID.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('moment-media', 'moment-media', false, 52428800,
        array['image/jpeg','image/png','image/webp','video/mp4','video/quicktime'])
on conflict (id) do update set public = false, file_size_limit = 52428800,
  allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "members upload their own moment media" on storage.objects;
create policy "members upload their own moment media" on storage.objects
for insert to authenticated with check (
  bucket_id = 'moment-media' and (storage.foldername(name))[1] = auth.uid()::text
);
drop policy if exists "members read moment media" on storage.objects;
create policy "members read moment media" on storage.objects
for select to authenticated using (
  bucket_id = 'moment-media' and exists (
    select 1 from public.social_moments m
    where m.media_path = name
      and not exists (select 1 from public.blocks b
        where (b.blocker_id = auth.uid() and b.blocked_id = m.author_id)
           or (b.blocker_id = m.author_id and b.blocked_id = auth.uid()))
  )
);
drop policy if exists "members delete own moment media" on storage.objects;
create policy "members delete own moment media" on storage.objects
for delete to authenticated using (
  bucket_id = 'moment-media' and (storage.foldername(name))[1] = auth.uid()::text
);

grant select, insert, delete on public.moment_likes to authenticated;
grant select, insert, update, delete on public.social_moments to authenticated;
grant select, insert, update, delete on public.moment_comments to authenticated;
grant update (media_path, media_type) on public.social_moments to authenticated;

-- Public profile thumbnails: only the owner can upload or replace their own file.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('profile-media', 'profile-media', true, 10485760,
        array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public = true, file_size_limit = 10485760,
  allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "members upload their own profile photo" on storage.objects;
create policy "members upload their own profile photo" on storage.objects
for insert to authenticated with check (
  bucket_id = 'profile-media' and (storage.foldername(name))[1] = auth.uid()::text
);
drop policy if exists "members replace their own profile photo" on storage.objects;
create policy "members replace their own profile photo" on storage.objects
for update to authenticated using (
  bucket_id = 'profile-media' and (storage.foldername(name))[1] = auth.uid()::text
) with check (
  bucket_id = 'profile-media' and (storage.foldername(name))[1] = auth.uid()::text
);
drop policy if exists "members delete their own profile photo" on storage.objects;
create policy "members delete their own profile photo" on storage.objects
for delete to authenticated using (
  bucket_id = 'profile-media' and (storage.foldername(name))[1] = auth.uid()::text
);
