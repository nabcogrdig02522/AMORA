-- AMORA virtual gifts and weekly leaderboard.
-- Apply after 20261202_moments_media_interactions.sql.
-- Gifts spend non-cash engagement points only. Points are not withdrawable,
-- transferable, or redeemable for money.

create table if not exists public.amora_gift_catalog (
  id text primary key,
  title text not null,
  emoji text not null,
  points_cost integer not null check (points_cost > 0),
  active boolean not null default true,
  sort_order integer not null default 0
);
insert into public.amora_gift_catalog(id,title,emoji,points_cost,active,sort_order)
values
 ('rose','Rose','🌹',10,true,1),
 ('coffee','Coffee','☕',20,true,2),
 ('chocolate','Chocolate','🍫',35,true,3),
 ('teddy','Teddy bear','🧸',60,true,4),
 ('heart','Heart','💖',100,true,5),
 ('crown','Golden crown','👑',250,true,6)
on conflict (id) do update set
 title=excluded.title, emoji=excluded.emoji, points_cost=excluded.points_cost,
 active=excluded.active, sort_order=excluded.sort_order;

alter table public.amora_gift_catalog enable row level security;
drop policy if exists "authenticated members read active gift catalogue" on public.amora_gift_catalog;
create policy "authenticated members read active gift catalogue"
on public.amora_gift_catalog for select to authenticated using (active = true);
grant select on public.amora_gift_catalog to authenticated;

create table if not exists public.amora_gift_transactions (
 id uuid primary key default gen_random_uuid(),
 sender_id uuid not null references auth.users(id) on delete cascade,
 recipient_id uuid not null references auth.users(id) on delete cascade,
 gift_id text not null references public.amora_gift_catalog(id),
 points_spent integer not null check (points_spent > 0),
 created_at timestamptz not null default now(),
 check (sender_id <> recipient_id)
);
create index if not exists amora_gift_transactions_received_idx
 on public.amora_gift_transactions(recipient_id, created_at desc);
create index if not exists amora_gift_transactions_week_idx
 on public.amora_gift_transactions(created_at desc);
alter table public.amora_gift_transactions enable row level security;

drop policy if exists "members read gifts they sent or received" on public.amora_gift_transactions;
create policy "members read gifts they sent or received"
on public.amora_gift_transactions for select to authenticated
using (sender_id = auth.uid() or recipient_id = auth.uid());
grant select on public.amora_gift_transactions to authenticated;

create or replace function public.amora_send_gift(p_recipient_id uuid, p_gift_id text)
returns table(transaction_id uuid, points_remaining bigint)
language plpgsql security definer set search_path = public
as $$
declare
 v_sender uuid := auth.uid();
 v_cost integer;
 v_wallet bigint;
 v_tx uuid;
begin
 if v_sender is null then raise exception 'Authentication required'; end if;
 if p_recipient_id is null or p_recipient_id = v_sender then
   raise exception 'Choose another active AMORA member';
 end if;
 if not exists (select 1 from public.profiles p where p.id=v_sender
   and p.is_active=true and coalesce(p.account_status,'active')='active') then
   raise exception 'Active AMORA account required';
 end if;
 if not exists (select 1 from public.profiles p where p.id=p_recipient_id
   and p.is_active=true and coalesce(p.account_status,'active')='active') then
   raise exception 'Recipient is not available';
 end if;
 if exists (select 1 from public.blocks b where
   (b.blocker_id=v_sender and b.blocked_id=p_recipient_id) or
   (b.blocker_id=p_recipient_id and b.blocked_id=v_sender)) then
   raise exception 'Gifts cannot be sent between blocked members';
 end if;
 select points_cost into v_cost from public.amora_gift_catalog
   where id=p_gift_id and active=true;
 if v_cost is null then raise exception 'This gift is not available'; end if;
 -- Lock the wallet row to prevent concurrent overspending.
 select points_balance into v_wallet from public.member_reward_wallets
   where user_id=v_sender for update;
 if v_wallet is null then
   insert into public.member_reward_wallets(user_id,points_balance)
   values(v_sender,0) on conflict(user_id) do nothing;
   select points_balance into v_wallet from public.member_reward_wallets
     where user_id=v_sender for update;
 end if;
 if v_wallet < v_cost then raise exception 'Not enough AMORA points'; end if;
 update public.member_reward_wallets
   set points_balance=points_balance-v_cost, updated_at=now()
   where user_id=v_sender returning points_balance into v_wallet;
 insert into public.amora_gift_transactions(sender_id,recipient_id,gift_id,points_spent)
   values(v_sender,p_recipient_id,p_gift_id,v_cost) returning id into v_tx;
 return query select v_tx,v_wallet;
end;
$$;
revoke all on function public.amora_send_gift(uuid,text) from public, anon;
grant execute on function public.amora_send_gift(uuid,text) to authenticated;

create or replace function public.amora_gift_leaderboard(p_limit integer default 20)
returns table(member_id uuid, display_name text, photo_url text, gifts_received bigint, points_received bigint)
language sql stable security definer set search_path = public
as $$
 select p.id, p.display_name, p.photo_url,
        count(t.id)::bigint, coalesce(sum(t.points_spent),0)::bigint
 from public.profiles p
 left join public.amora_gift_transactions t
   on t.recipient_id=p.id
  and t.created_at >= date_trunc('week', now())
  and t.created_at < date_trunc('week', now()) + interval '1 week'
 where p.is_active=true and coalesce(p.account_status,'active')='active'
   and p.id <> auth.uid()
   and not exists (select 1 from public.blocks b where
     (b.blocker_id=auth.uid() and b.blocked_id=p.id) or
     (b.blocker_id=p.id and b.blocked_id=auth.uid()))
 group by p.id,p.display_name,p.photo_url
 having count(t.id)>0
 order by count(t.id) desc, coalesce(sum(t.points_spent),0) desc
 limit greatest(1,least(coalesce(p_limit,20),50));
$$;
revoke all on function public.amora_gift_leaderboard(integer) from public, anon;
grant execute on function public.amora_gift_leaderboard(integer) to authenticated;

create or replace function public.amora_my_gift_balance()
returns bigint language sql stable security definer set search_path=public
as $$
 select coalesce((select points_balance from public.member_reward_wallets
   where user_id=auth.uid()),0);
$$;
revoke all on function public.amora_my_gift_balance() from public, anon;
grant execute on function public.amora_my_gift_balance() to authenticated;
