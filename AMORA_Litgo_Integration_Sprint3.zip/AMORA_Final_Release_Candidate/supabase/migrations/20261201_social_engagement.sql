-- AMORA social engagement foundation
-- Adds a text-first Moments feed and a once-per-day points check-in.
-- Apply after 20261130_release_candidate_admin_analytics.sql.

create table if not exists public.social_moments (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(trim(body)) between 1 and 1000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists social_moments_created_idx
  on public.social_moments(created_at desc);
create index if not exists social_moments_author_idx
  on public.social_moments(author_id, created_at desc);

alter table public.social_moments enable row level security;

drop policy if exists "active members read moments excluding blocked users" on public.social_moments;
create policy "active members read moments excluding blocked users"
on public.social_moments for select to authenticated
using (
  exists (select 1 from public.profiles me
    where me.id = auth.uid() and me.is_active = true
      and coalesce(me.account_status, 'active') = 'active')
  and not exists (
    select 1 from public.blocks b
    where (b.blocker_id = auth.uid() and b.blocked_id = author_id)
       or (b.blocker_id = author_id and b.blocked_id = auth.uid())
  )
);

drop policy if exists "members publish own moments" on public.social_moments;
create policy "members publish own moments"
on public.social_moments for insert to authenticated
with check (
  author_id = auth.uid()
  and exists (select 1 from public.profiles p
    where p.id = auth.uid() and p.is_active = true
      and coalesce(p.account_status, 'active') = 'active')
);

drop policy if exists "members edit own moments" on public.social_moments;
create policy "members edit own moments"
on public.social_moments for update to authenticated
using (author_id = auth.uid())
with check (author_id = auth.uid());

drop policy if exists "members delete own moments" on public.social_moments;
create policy "members delete own moments"
on public.social_moments for delete to authenticated
using (author_id = auth.uid());

create table if not exists public.member_reward_wallets (
  user_id uuid primary key references auth.users(id) on delete cascade,
  points_balance bigint not null default 0 check (points_balance >= 0),
  updated_at timestamptz not null default now()
);
alter table public.member_reward_wallets enable row level security;
drop policy if exists "members read own reward wallet" on public.member_reward_wallets;
create policy "members read own reward wallet"
on public.member_reward_wallets for select to authenticated
using (user_id = auth.uid());

create table if not exists public.member_daily_checkins (
  user_id uuid not null references auth.users(id) on delete cascade,
  checkin_date date not null default (timezone('utc', now())::date),
  points_awarded integer not null default 5 check (points_awarded > 0),
  created_at timestamptz not null default now(),
  primary key (user_id, checkin_date)
);
alter table public.member_daily_checkins enable row level security;
drop policy if exists "members read own checkins" on public.member_daily_checkins;
create policy "members read own checkins"
on public.member_daily_checkins for select to authenticated
using (user_id = auth.uid());

create or replace function public.amora_daily_check_in()
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_points integer := 5;
begin
  if v_user is null then
    raise exception 'Authentication required';
  end if;

  if not exists (
    select 1 from public.profiles p
    where p.id = v_user and p.is_active = true
      and coalesce(p.account_status, 'active') = 'active'
  ) then
    raise exception 'Active AMORA account required';
  end if;

  insert into public.member_daily_checkins(user_id, checkin_date, points_awarded)
  values (v_user, timezone('utc', now())::date, v_points)
  on conflict (user_id, checkin_date) do nothing;

  if not found then
    return 0;
  end if;

  insert into public.member_reward_wallets(user_id, points_balance, updated_at)
  values (v_user, v_points, now())
  on conflict (user_id) do update
    set points_balance = public.member_reward_wallets.points_balance + excluded.points_balance,
        updated_at = now();

  return v_points;
end;
$$;

revoke all on function public.amora_daily_check_in() from public, anon;
grant execute on function public.amora_daily_check_in() to authenticated;

-- Realtime is enabled by the app's Supabase project configuration, not by client code.
